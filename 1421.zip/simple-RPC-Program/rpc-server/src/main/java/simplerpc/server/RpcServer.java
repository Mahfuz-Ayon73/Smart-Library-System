package simplerpc.server;

import java.io.IOException;

public interface RpcServer {

    void start() throws IOException;

    <T> void export(Class<T> serviceInterface, Class<? extends T> serviceImpl);
}
