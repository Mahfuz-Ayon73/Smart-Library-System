package simplerpc.server;

import simplerpc.common.HelloService;

public class HelloServiceImpl implements HelloService {

    @Override
    public String greet(String name, String country) {
        return "Hello " + name + "@" + country + "!!!";
    }
}
