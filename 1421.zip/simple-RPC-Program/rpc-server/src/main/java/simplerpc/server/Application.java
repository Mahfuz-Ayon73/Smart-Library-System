package simplerpc.server;

import java.io.IOException;

import simplerpc.common.HelloService;

public class Application {

    public static void main(String[] args) throws IOException {
        RpcServer server = new RpcServerImpl(8080, 3);
        server.export(HelloService.class, HelloServiceImpl.class);
        server.start();
    }
}
