package simplerpc.client;

import simplerpc.common.HelloService;

public class Application {

    public static void main(String[] args) {
        RpcClient client = new RpcClientImpl();
        HelloService service = client.proxy(HelloService.class, "localhost", 8080);
        String greeting = service.greet("Hello", "IIT");
        System.out.println("RpcServer returns: " + greeting);
    }
}
