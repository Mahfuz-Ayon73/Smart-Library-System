package simplerpc.common;

public interface HelloService {

    String greet(String name, String country);
}
